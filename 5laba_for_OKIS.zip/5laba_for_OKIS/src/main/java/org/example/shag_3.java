package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.Duration;

public class shag_3 {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.edge.driver", "msedgedriver.exe");
        WebDriver driver = new EdgeDriver();
        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        driver.get("https://testng.org/");
        wait.until(ExpectedConditions.titleContains("TestNG"));


        String pageTitle = driver.getTitle();
        System.out.println("Заголовок страницы: " + pageTitle);
    }
}