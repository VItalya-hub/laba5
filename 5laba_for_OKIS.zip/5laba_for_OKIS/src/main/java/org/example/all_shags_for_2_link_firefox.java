package org.example;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class all_shags_for_2_link_firefox {

    public static void main(String[] args) {

        System.setProperty("webdriver.firefox.driver", "geckodriver.exe");


        WebDriver driver = new FirefoxDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {

            driver.get("https://javarush.com/");
            driver.manage().window().maximize();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("h1")));

            String pageTitle = driver.getTitle();
            System.out.println("Заголовок сайта: " + pageTitle);


            List<WebElement> tocItems = driver.findElements(
                    By.cssSelector("a[href*='#'], .toc-item, [class*='toc'], nav a")
            );


            List<String> tocTitles = new ArrayList<>();
            for (WebElement item : tocItems) {
                String text = item.getText().trim();
                if (!text.isEmpty() && text.length() < 100) {
                    tocTitles.add(text);
                }
            }


            System.out.println("Найденные элементы содержания (" + tocTitles.size() + "):");
            for (int i = 0; i < tocTitles.size(); i++) {
                System.out.println((i + 1) + ". " + tocTitles.get(i));
            }


            if (!tocTitles.isEmpty()) {

                try {
                    WebElement firstCssElement = driver.findElement(
                            By.cssSelector("a[href]:not([href='']), button, [onclick]")
                    );
                    System.out.println("Нажимаем элемент с текстом: " + firstCssElement.getText().trim());

                    ((JavascriptExecutor)driver).executeScript(
                            "arguments[0].scrollIntoView(true);", firstCssElement
                    );
                    Thread.sleep(1000);
                    firstCssElement.click();
                    Thread.sleep(2000);
                } catch (Exception e) {
                    System.out.println("Не удалось кликнуть CSS-элемент: " + e.getMessage());
                }


                driver.get("https://javarush.com/");
                wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("h1")));


                try {
                    WebElement firstXpathElement = driver.findElement(
                            By.xpath("//a[contains(@href, '#') or contains(text(), 'курс') or contains(text(), 'обучение')]")
                    );
                    System.out.println("Нажимаем элемент с текстом: " + firstXpathElement.getText().trim());
                    ((JavascriptExecutor)driver).executeScript(
                            "arguments[0].scrollIntoView(true);", firstXpathElement
                    );
                    Thread.sleep(1000);
                    firstXpathElement.click();
                    Thread.sleep(2000);
                } catch (Exception e) {
                    System.out.println("Не удалось кликнуть XPath-элемент: " + e.getMessage());
                }
            }

        } catch (Exception e) {
            System.err.println("Произошла ошибка: " + e.getMessage());
            e.printStackTrace();
        } finally {

            System.out.println("\n=== Завершение работы ===");
            if (driver != null) {
                driver.quit();
                System.out.println("Браузер закрыт.");
            }
        }
    }
}