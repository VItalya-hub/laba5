package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class all_shags_for_1_link_firefox {
    public static void main(String[] args) {

        WebDriver driver = new FirefoxDriver();

        try {
            driver.manage().window().maximize();
            driver.get("https://mathprofi.ru/");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.titleContains("Высшая математика"));

            String title = driver.getTitle();
            System.out.println("Заголовок: " + title);


            List<WebElement> menuItems = driver.findElements(
                    By.cssSelector("ul.nav, ul.menu, ul:has(a), div.menu a, a")
            );

            System.out.println("Найдено ссылок на странице: " + menuItems.size());


            int count = 0;
            for (WebElement item : menuItems) {
                String text = item.getText();
                if (!text.isEmpty() && text.length() < 50) {
                    System.out.println(count + ". Текст: '" + text);
                    count++;
                }
                if (count >= 20) break;
            }


            List<WebElement> divs = driver.findElements(By.tagName("div"));
            System.out.println("Всего div элементов: " + divs.size());

            WebElement siteMapLink = null;


            try {
                siteMapLink = driver.findElement(
                        By.xpath("//a[contains(text(), 'Карта сайта')]")
                );
            } catch (Exception e1) {

                    }

            if (siteMapLink != null) {
                System.out.println("\nКликаем на: " + siteMapLink.getText());
                siteMapLink.click();
                Thread.sleep(3000);


                // Возвращаемся назад
                driver.navigate().back();
                Thread.sleep(2000);
            } else {
                System.out.println("\nСсылка 'Карта сайта' не найдена!");


                try {
                    WebElement firstMenuLink = driver.findElement(
                            By.xpath("//nav//a | //div[contains(@class, 'menu')]//a | //ul[contains(@class, 'menu')]//a")
                    );
                    System.out.println("Найдена первая ссылка меню: " + firstMenuLink.getText());
                    firstMenuLink.click();
                    Thread.sleep(3000);
                    driver.navigate().back();
                    Thread.sleep(2000);
                } catch (Exception e) {
                    System.out.println("Не удалось найти меню");
                }
            }


            List<WebElement> allPageLinks = driver.findElements(By.tagName("a"));
            if (allPageLinks.size() > 5) {
                WebElement testLink = allPageLinks.get(5);
                System.out.println("Кликаем на: " + testLink.getText());
                testLink.click();
                Thread.sleep(3000);
                driver.navigate().back();
                Thread.sleep(2000);
            }

        } catch (Exception e) {
            System.out.println("Ошибка: " + e.getMessage());
            e.printStackTrace();
        } finally {
            System.out.println("\nЗавершение работы...");
            driver.quit();
        }
    }
}