package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.Duration;

public class shag_4 {
    public static void main(String[] args) {
        WebDriver driver = null;
        try {
            System.setProperty("webdriver.edge.driver", "msedgedriver.exe");
            driver = new EdgeDriver();
            driver.manage().window().maximize();
            driver.get("https://testng.org/");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            wait.until(ExpectedConditions.titleContains("TestNG"));

            String pageTitle = driver.getTitle();
            System.out.println("Заголовок страницы: " + pageTitle);
        }

        catch (Exception e) {
            System.err.println("Произошла ошибка: " + e.getMessage());
        }
        finally {
            driver.quit();
        }
        System.out.println("Браузер успешно закрыт.");
    }
}