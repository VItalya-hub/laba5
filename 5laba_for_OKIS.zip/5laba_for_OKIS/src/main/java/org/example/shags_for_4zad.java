package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;


public class shags_for_4zad {
    public static void main(String[] args) {
        WebDriver driver = new EdgeDriver();

        try {
            driver.get("https://testng.org/");
            driver.manage().window().maximize();
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.titleContains("TestNG"));

            List<WebElement> Items = driver.findElements(
                    By.cssSelector("div.toc li a, .toc li a, li a")
            );

            System.out.println("Table of Contents сайта TestNG:");
            int itemCount = 0;
            for (WebElement item:Items) {
                String text = item.getText();
                if (!text.isEmpty() && text.length() < 100) {
                    itemCount++;
                    System.out.println(itemCount + ". " + text);
                }
            }
            System.out.println("Всего найдено элементов: " + itemCount);



            WebElement linkByCss = driver.findElement(By.cssSelector("div.toc li:first-child a"));
            System.out.println("Найденный элемент (CSS): " + linkByCss.getText());
            linkByCss.click();
            System.out.println("Клик выполнен с помощью CSS Selector.");


            wait.until(ExpectedConditions.urlContains("#"));

            Thread.sleep(1000);


            driver.get("https://testng.org/");
            wait.until(ExpectedConditions.titleContains("TestNG"));


            System.out.println("\n--- Метод 2: Поиск и клик с помощью XPath ---");


            WebElement linkByXpath = driver.findElement(
                    By.xpath("//div[contains(@class, 'toc')]//li//a[contains(normalize-space(), 'Welcome to TestNG')]")
            );
            System.out.println("Найденный элемент (XPath): " + linkByXpath.getText());
            linkByXpath.click();
            System.out.println("Клик выполнен с помощью XPath.");


            Thread.sleep(2000);

        } catch (Exception e) {
            System.out.println("Ошибка: " + e.getMessage());
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}

